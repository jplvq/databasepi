package classes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Cliente {
	private Integer id;
	private String nome;
	private String senha;
	private String endereco;
	private String telefone;
	private String email;
	private Integer sexo;
	private ResultSet rs;


	public Integer getId() { return id; }
	public void    setId(Integer id) { this.id = id; }
	
	public String getNome() { return nome; }
	public void   setNome(String nome) { this.nome = nome; }
	
	public String getSenha() { return senha; }
	public void   setSenha(String senha) { this.senha = senha; }
	
	public String getEndereco() { return nome; }
	public void   setEndereco(String endereco) { this.endereco = endereco; }
	
	public String getTelefone() { return telefone; }
	public void   setTelefone(String telefone) { this.telefone = telefone; }
	
	public String getEmail() { return email; }
	public void   setEmail(String email) { this.email = email; }
	
	public Integer getSexo() { return sexo; }
	public void   setSexo(Integer sexo) { this.sexo = sexo; }


	public String cadastrar() {
		try {
			ConectaBD cbd = new ConectaBD();
			Connection conn = cbd.Conectar();

			String sql = "INSERT INTO cliente (nome, senha, endereco, telefone, email, sexo) VALUES (?, ?, ?, ?, ?, ?);";

	        PreparedStatement comando = conn.prepareStatement(sql);
	        comando.setString(1, this.nome);
	        comando.setString(2, this.senha);
	        comando.setString(3, this.endereco);
	        comando.setString(4, this.telefone);
	        comando.setString(5, this.email);
	        comando.setInt(6, this.sexo);
	        comando.execute();
	        comando.close();
	        conn.close();

	        return "";
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	public ResultSet listar(int id, int offset) {
		try {
	   		ConectaBD cbd = new ConectaBD();
	   		Connection conn = cbd.Conectar();

	   		String sql;
	   		if (id == 0) {
		   	 	sql = "SELECT id, nome, senha, endereco, telefone, email, sexo FROM cliente LIMIT " + offset + ", 10;";
	   		} else {
		   	 	sql = "SELECT id, nome, senha, endereco, telefone, email, sexo FROM cliente WHERE id=" + id + " LIMIT " + offset + ", 10;";
	   		}

	   	 	Statement st = conn.createStatement();
	   	   	rs = st.executeQuery(sql);

	   	   	return rs;
		} catch (Exception e) {
			System.out.println(e.getMessage());
	   	   	return null;
		}
	}
	
	public String alterar() {
		try {
			ConectaBD cbd = new ConectaBD();
			Connection conn = cbd.Conectar();

			String sql = "UPDATE cliente SET nome=?, senha=?, endereco=?, telefone=?, email=?, sexo=? WHERE id=?;";

	        PreparedStatement comando = conn.prepareStatement(sql);
	        comando.setString(1, this.nome);
	        comando.setString(2, this.senha);
	        comando.setString(3, this.endereco);
	        comando.setString(4, this.telefone);
	        comando.setString(5, this.email);
	        comando.setInt(6, this.sexo);
	        comando.setInt(7, id);
	        comando.execute();
	        comando.close();
	        conn.close();

	        return "";
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	public String deletar() {
		try {
	   		ConectaBD cbd = new ConectaBD();
	   		Connection conn = cbd.Conectar();

	   		String sql = "DELETE FROM cliente WHERE id=?;";
	   	   	PreparedStatement pst = conn.prepareStatement(sql);
	   	   	pst.setInt(1, id);
	   	 	pst.execute();

	   	 	return "";
		} catch (Exception e) {
			return e.getMessage();
		}
	}
}